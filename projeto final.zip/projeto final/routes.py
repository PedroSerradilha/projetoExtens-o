from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
#from models import db, Usuario  # Importa o banco de dados e o modelo Usuario

def setup_routes(app, mysql):
    @app.route('/')
    def index():
        return render_template('home.html')


    @app.route('/cadastrar', methods=['GET', 'POST'])
    def cadastrar():
        if request.method == 'POST':
            nome = request.form['nome']
            dia = request.form['dia']
            mes = request.form['mes']
            ano = request.form['ano']
            sexo = request.form['sexo']
            email = request.form['email']
            senha = request.form['senha']

            cursor = mysql.connection.cursor()
            cursor.execute("INSERT INTO usuario (nome_usuario, data_nascimento, sexo, email_usuario, senha_usuario) VALUES (%s, %s, %s, %s, %s)",
                           (nome, f"{ano}-{mes}-{dia}", sexo, email, senha))
            mysql.connection.commit()
            cursor.close()

            return redirect(url_for('login'))
        return render_template('cadastro.html') 
    
    #@app.route('/login')
    #def login():
        #return render_template('login.html')  


    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            email = request.form['email_usuario']
            senha = request.form['senha_usuario']

            try:
                cursor = mysql.connection.cursor()
                cursor.execute("SELECT id_usuario, senha_usuario FROM usuario WHERE email_usuario = %s", (email,))
                resultado = cursor.fetchone()
                cursor.close()

                if resultado:
                    id_usuario, senha_hash = resultado  # Aqui, senha_hash é a senha em texto simples

                    # Compare a senha fornecida com a senha armazenada
                    if senha == senha_hash:
                        session['user_id'] = id_usuario  # Armazena o ID do usuário na sessão
                        flash('Login realizado com sucesso!', 'success')
                        return redirect(url_for('dashboard'))
                    else:
                        flash('Email ou senha incorretos. Tente novamente.', 'error')
                else:
                    flash('Email ou senha incorretos. Tente novamente.', 'error')

            except Exception as e:
                print(f"Erro ao realizar login: {e}")
                flash('Ocorreu um erro ao tentar fazer login. Tente novamente mais tarde.', 'error')

            return redirect(url_for('login'))

        return render_template('login.html')

    @app.route('/dashboard', methods=['GET', 'POST'])
    def dashboard():
        if request.method == 'POST':
            # Aqui você pode processar o formulário se necessário
            pass
        return render_template('dashboard.html')
    
    @app.route('/recomendacao', methods=['GET'])
    def recomendacao():
        sintomas = request.args.getlist('sintomas')  # Obtém os sintomas selecionados
        alimentos_recomendados = []
        id_usuario = session.get('user_id')  # Obtém o ID do usuário da sessão

        if not id_usuario:
            flash('Você precisa estar logado para acessar essa página.', 'error')
            return redirect(url_for('login'))  # Redireciona para a página de login se não estiver logado

        for sintoma in sintomas:
            cursor = mysql.connection.cursor()
            cursor.execute("SELECT alimento, descricao FROM recomendacoes WHERE sintoma = %s", (sintoma,))
            resultados = cursor.fetchall()

            for resultado in resultados:
                alimento = resultado[0]
                descricao = resultado[1]
                alimentos_recomendados.append({
                    'alimento': alimento,
                    'descricao': descricao
                })
                
                # Inserir no histórico de recomendações
                cursor.execute("INSERT INTO historico_recomendacoes (id_usuario, sintoma, alimento, descricao) VALUES (%s, %s, %s, %s)",
                            (id_usuario, sintoma, alimento, descricao))  # Usar o id_usuario da sessão
            
        mysql.connection.commit()  # Confirma as alterações no banco de dados
        cursor.close()

        return render_template('recomendacao.html', alimentos=alimentos_recomendados)

    @app.route('/historico', methods=['GET'])
    def historico():
        id_usuario = session.get('user_id')  # Obtém o ID do usuário da sessão

        if not id_usuario:
            flash('Você precisa estar logado para acessar essa página.', 'error')
            return redirect(url_for('login'))  # Redireciona para a página de login se não estiver logado

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT sintoma, alimento, descricao, data_recomendacao FROM historico_recomendacoes WHERE id_usuario = %s ORDER BY data_recomendacao DESC", (id_usuario,))
        resultados = cursor.fetchall()
        cursor.close()

        # Formatar os resultados para um dicionário
        historico_recomendacoes = []
        for resultado in resultados:
            historico_recomendacoes.append({
                'sintoma': resultado[0],
                'alimento': resultado[1],
                'descricao': resultado[2],
                'data_recomendacao': resultado[3]
            })

        return render_template('historico.html', historico=historico_recomendacoes)

    @app.route('/noticias', methods=['GET'])
    def noticias():
        return render_template('noticias.html')
    
    #@app.route('/recuperar_senha', methods=['GET'])
    #def recuperar_senha():
    #    return render_template('recuperar_senha.html')

    @app.route('/recuperar_senha', methods=['GET', 'POST'])
    def recuperar_senha():
        if request.method == 'POST':
            email = request.form['emailRecuperacao']
            nova_senha = request.form['senha_usuario']

            cursor = mysql.connection.cursor()
            # Verifica se o email está cadastrado
            cursor.execute("SELECT * FROM usuario WHERE email_usuario = %s", (email,))
            usuario = cursor.fetchone()

            if usuario:
                # Atualiza a senha no banco de dados
                cursor.execute("UPDATE usuario SET senha_usuario = %s WHERE email_usuario = %s", (nova_senha, email))
                mysql.connection.commit()
                cursor.close()
                flash('Senha atualizada com sucesso!', 'success')
                return redirect(url_for('login'))  # Redireciona para a página de login
            else:
                cursor.close()
                flash('Email não encontrado no sistema.', 'error')

        return render_template('recuperar_senha.html')
    
    @app.route('/politica', methods=['GET'])
    def politica():
        return render_template('politica.html')
    
    @app.route('/termos', methods=['GET'])
    def termos():
        return render_template('termos.html')
    
    #@app.route('/config', methods=['GET'])
    #def config():
    #    return render_template('configuração.html')

    @app.route('/config', methods=['GET', 'POST'])
    def config():
        id_usuario = session.get('user_id')

        if not id_usuario:
            flash('Você precisa estar logado para acessar essa página.', 'error')
            return redirect(url_for('login'))

        if request.method == 'POST':
            nome = request.form['nome']
            email = request.form['email']
            senha = request.form['senha']
            data_nascimento = request.form['data_nascimento']

            try:
                cursor = mysql.connection.cursor()
                cursor.execute("""
                    UPDATE usuario 
                    SET nome_usuario = %s, email_usuario = %s, senha_usuario = %s, data_nascimento = %s 
                    WHERE id_usuario = %s
                """, (nome, email, senha, data_nascimento, id_usuario))
                mysql.connection.commit()
                cursor.close()

                flash('Dados atualizados com sucesso!', 'success')
                return redirect(url_for('config'))
            except Exception as e:
                print(f"Erro ao atualizar dados: {e}")
                flash('Ocorreu um erro ao atualizar seus dados. Tente novamente mais tarde.', 'error')

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT nome_usuario, email_usuario, data_nascimento FROM usuario WHERE id_usuario = %s", (id_usuario,))
        usuario = cursor.fetchone()
        cursor.close()

        # Aqui, usuario[2] deve ser um objeto de data (datetime.date)
        # Formatar a data para YYYY-MM-DD
        data_nascimento_formatada = usuario[2].strftime('%Y-%m-%d') if usuario[2] else None

        return render_template('configuração.html', usuario=(usuario[0], usuario[1], data_nascimento_formatada))

    if __name__ == '__main__':
        app.run(debug=True)
    

    

    
    