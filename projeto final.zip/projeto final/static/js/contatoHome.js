document.getElementById('formContato').addEventListener('submit', function(event) {
    event.preventDefault(); // Previne o envio real do formulário

    // Aqui podemos pegar os dados preenchidos, mas para esse exemplo vamos apenas mostrar a mensagem de sucesso.
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    
    // Para simular o envio, mostramos uma mensagem de sucesso
    console.log("Nome:", name);
    console.log("E-mail:", email);
    console.log("Mensagem:", message);
    
    // Exibe a mensagem de sucesso
    const successMessage = document.getElementById('successMessage');
    successMessage.style.display = 'block'; // Exibe a mensagem
});