from flask import Flask
from flask_mysqldb import MySQL
from config import Config
from routes import setup_routes

app = Flask(__name__)
app.config.from_object(Config)

app.secret_key = '123'

# Inicializa a conexão com o MySQL
mysql = MySQL(app)

# Configura as rotas
setup_routes(app, mysql)

if __name__ == '__main__':
    app.run(debug=True)