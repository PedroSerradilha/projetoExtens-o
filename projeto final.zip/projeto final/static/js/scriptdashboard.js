function showPage(pageId) {
    // Oculta todas as seções de conteúdo
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    // Exibe apenas a seção selecionada
    document.getElementById(pageId).style.display = 'block';

    // Atualiza a classe "active" no menu lateral
    document.querySelectorAll('.sidebar a').forEach(link => {
        link.classList.remove('active');
    });
    event.target.classList.add('active');
}
