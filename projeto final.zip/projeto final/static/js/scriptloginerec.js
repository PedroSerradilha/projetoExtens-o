document.addEventListener("DOMContentLoaded", function() {
    // Evento de submissão do formulário de login
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const email = document.getElementById("email").value;
            const senha = document.getElementById("senha").value;

            if (email && senha) {
                alert("Login realizado com sucesso!");
                // Adicione a lógica de autenticação aqui
            } else {
                alert("Por favor, preencha todos os campos.");
            }
        });
    }

    // Evento de submissão do formulário de recuperação de senha
    const recuperacaoForm = document.getElementById("recuperacaoForm");
    if (recuperacaoForm) {
        recuperacaoForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const emailRecuperacao = document.getElementById("emailRecuperacao").value;

            if (emailRecuperacao) {
                alert("Link de recuperação enviado para " + emailRecuperacao);
                // Adicione a lógica para envio do link de recuperação aqui
            } else {
                alert("Por favor, insira seu email.");
            }
        });
    }
});
